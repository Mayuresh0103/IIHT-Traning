import java.sql.*;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.ResultSet;

public class ResetPwd {

    static final String D_URL ="jdbc:mysql://localhost:3306/cognidemo";
    static final String USER ="root";
    static final String PASS ="pass@word1";
    static final String QUERY ="update register set password=? where email=? ;";

    public static void reset() {
        try(Connection con =DriverManager.getConnection(D_URL,USER,PASS);
            Statement stmt= con.createStatement();

            PreparedStatement ps = con.prepareStatement(QUERY);)
        {
            Scanner sc = new Scanner(System.in);
             System.out.println("Password Rest Page :");
            System.out.println("---------------------");
            System.out.println("Enter email:");
            //  String fname =sc.nextLine();
            String email =sc.nextLine();
         //   System.out.println("email" +email);
        //   System.out.println("Enter your Old Password");
           // String pass =sc.nextLine();
            System.out.println("New Password ");
            String pass =sc.nextLine();


            // ps.setString(1,fname);
           // ps.setString(2,email);
          //  System.out.println("print" +ps);
            ps.setString(1,pass);
           // System.out.println("printmpass" +ps);
             ps.setString(2,email);
          //   System.out.println("printemail" +ps);

           int b =  ps.executeUpdate();
          //  System.out.println("print" +ps);
            if(b==1) {
                System.out.println("Password Successfully Updated");

            }
            else {
                System.out.println("Password Update Failed");
            }

        }

        catch(SQLException e)
        {

        }



    }
}








