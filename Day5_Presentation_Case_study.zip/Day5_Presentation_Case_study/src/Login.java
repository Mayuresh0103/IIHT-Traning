import java.sql.*;
import java.sql.Statement;
import java.util.Scanner;

public class Login {

    static final String D_URL ="jdbc:mysql://localhost:3306/cognidemo";
    static final String USER ="root";
    static final String PASS ="pass@word1";
    static final String QUERY ="select * from register where email=? and password=?;";
    static String email;

    public static void login(){
        try{
                Connection con =DriverManager.getConnection(D_URL,USER,PASS);
            Statement stmt= con.createStatement();

            PreparedStatement ps = con.prepareStatement(QUERY);

            Scanner sc = new Scanner(System.in);
          //  System.out.println("enter first name");
          //  String fname =sc.nextLine();
            System.out.println("Enter email address");
             email =sc.nextLine();
            System.out.println("Enter password ");
            String pass =sc.nextLine();


           // ps.setString(1,fname);
            ps.setString(1,email);
            ps.setString(2,pass);
            ResultSet rs =ps.executeQuery();
            if (rs.next()){
                System.out.println("Login Successfully ");
                System.out.println("---------------------");
                String sql = "update register" + "  SET status = 'YES' where email = '" +email +"'";
                //System.out.println("Result is " +sql);
                stmt.executeUpdate(sql);

               // ResultSet res =stmt.executeQuery(sql);

            }
            else {
                System.out.println("Login Failed");
            }
        }

        catch(SQLException e)
        {

        }



    }
    public static void logOut(){
        try{
       Connection con =DriverManager.getConnection(D_URL,USER,PASS);
       Statement stmt= con.createStatement();

        String sql = "update register" + "  SET status = 'NO' where email = '" +email +"'";
       // System.out.println("Result is " +sql);
        stmt.executeUpdate(sql);
        }
        catch(SQLException e)
        {

        }

    }
}



