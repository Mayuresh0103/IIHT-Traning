import java.sql.*;

public class Retrive_user {
    static final String D_URL ="jdbc:mysql://localhost:3306/cognidemo";
    static final String USER ="root";
    static final String PASS ="pass@word1";
    static final String QUERY ="select distinct email from tweets";

    public static void retriveUser()
    {
        try{
            Connection con =DriverManager.getConnection(D_URL,USER,PASS);

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);

            while (rs.next()) {

                //System.out.println("Tweet id: " + rs.getInt("tweet_id"));
                System.out.println("Email: " + rs.getString("email"));
               // System.out.println("Tweet : " + rs.getString("tweet"));

            }

        }

        catch(SQLException e)
        {

        }



    }




}











