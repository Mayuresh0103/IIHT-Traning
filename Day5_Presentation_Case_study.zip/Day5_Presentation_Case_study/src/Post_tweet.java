import java.sql.*;
import java.util.Scanner;

public class Post_tweet {

    static final String D_URL ="jdbc:mysql://localhost:3306/cognidemo";
    static final String USER ="root";
    static final String PASS ="pass@word1";
    static final String QUERY ="insert into tweets (tweet_id,email,tweet) values(?,?,?);";

    public static void addPost(){
        try(Connection con =DriverManager.getConnection(D_URL,USER,PASS);
            Statement stmt= con.createStatement();

            PreparedStatement ps = con.prepareStatement(QUERY))
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("enter email");
            String email =sc.nextLine();
            System.out.println("enter tweet");
            String tweet =sc.nextLine();
            System.out.println("enter tweet id");
            int id =sc.nextInt();


            ps.setInt(1,id);
            ps.setString(2,email);
            ps.setString(3,tweet);
            ps.executeUpdate();
        }

        catch(SQLException e)
        {

        }



    }
}
