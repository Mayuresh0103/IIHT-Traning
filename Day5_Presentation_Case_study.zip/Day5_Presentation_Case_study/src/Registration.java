import java.sql.*;
import java.sql.Statement;
import java.util.Scanner;

public class Registration {

    static final String D_URL ="jdbc:mysql://localhost:3306/cognidemo";
    static final String USER ="root";
    static final String PASS ="pass@word1";
    static final String QUERY ="insert into register (fname,email,password,status) values(?,?,?,?);";

    public static void register(){
        try(Connection con =DriverManager.getConnection(D_URL,USER,PASS);
            Statement stmt= con.createStatement();

            PreparedStatement ps = con.prepareStatement(QUERY);)
        {
            Scanner sc = new Scanner(System.in);

            System.out.println("Create An Account");

            System.out.println("Enter Full name");
            String fname =sc.nextLine();
            System.out.println("Enter Email address");
            String email =sc.nextLine();
            System.out.println("Enter password ");
            String pass =sc.nextLine();

            String status="NO";


            ps.setString(1,fname);
            ps.setString(2,email);
            ps.setString(3,pass);
            ps.setString(4,status);
            ps.executeUpdate();

            System.out.println("Registration Completed");
            System.out.println("---------------------");
        }

        catch(SQLException e)
        {

        }



    }
}


