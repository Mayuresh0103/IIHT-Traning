import java.sql.*;
import java.util.Scanner;

public class Delete {
    static final String D_URL ="jdbc:mysql://localhost:3306/cognidemo";
    static final String USER ="root";
    static final String PASS ="pass@word1";
    static final String QUERY ="delete from employees where emp_id ?;";


    public static void main(String args[])
    {

        try(Connection con =DriverManager.getConnection(D_URL,USER,PASS);
            Statement stmt= con.createStatement();

            PreparedStatement ps = con.prepareStatement(QUERY);) {
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter Emp id");
            int id =sc.nextInt();

            ResultSet rs = stmt.executeQuery("select emp_id,emp_name,emp_add from employees where emp_id ='"+ id + "'");

            if(rs.next()) {

                System.out.println("Before Delete: \n " );
                System.out.println("Employee id: " + rs.getInt("emp_id"));
                System.out.println("Employee Name: " + rs.getString("emp_name"));
                System.out.println("Address : " + rs.getString("emp_add"));

                ps.setInt(1,id);
                ps.executeUpdate();

            }
            else{
                System.out.println("Record not present \n " );

            }
        }

        catch(SQLException e)
        {

        }

    }
}
