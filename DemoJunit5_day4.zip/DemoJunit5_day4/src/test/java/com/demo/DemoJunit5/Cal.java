package com.demo.DemoJunit5;

public class Cal {
	
	public int doSum(int a, int b,int c) {
		return a+b+c;
	}
	
	public int doProduct(int a, int b) {
		return a*b;
	}
	
	public boolean campTonum(int a, int b) {
		return a==b;
	}

}
