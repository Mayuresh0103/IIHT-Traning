package com.demo.repo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import com.demo.DemoJunit5.Person;

class PersonRepoTest {

	@Autowired
	
	private PersonRepo personRepo;
	
	@Test
	void isPersonExistsById() {
		Person person = new Person(14,"santosh");
		personRepo.save(person);
		
		Boolean acRes=personRepo.isPersonExistById(14);
		assertThat(acRes).isTrue();
	}
	
	
	@BeforeEach
	void setUp() {
		
	System.out.println("Setup is Started");
	}
	
	
	@AfterEach
	void tearDown() {
		System.out.println("Test Over");
		personRepo.deleteAll();
	}

}
