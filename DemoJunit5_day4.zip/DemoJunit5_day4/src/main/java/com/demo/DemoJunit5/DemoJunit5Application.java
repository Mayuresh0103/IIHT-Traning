package com.demo.DemoJunit5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJunit5Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJunit5Application.class, args);
	}

}
