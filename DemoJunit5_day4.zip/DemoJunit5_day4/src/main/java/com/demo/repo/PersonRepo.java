package com.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.DemoJunit5.Person;

public interface PersonRepo extends JpaRepository<Person,Integer> {
	
	@Query("SELECT CASE WHEN COUNT(s)>0 THEN TRUE ELSE FALSE" 
			+ "END FROM PERSON s WHERE S.personId= ?1")
	Boolean isPersonExistById(Integer id);

	List<Person> findAll();

}
