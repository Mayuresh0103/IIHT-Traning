package Practice_prog;

public class Demo {

	public static void main(String[] args) {
		//int i= 3;
		//System.out.println(i++*8);
		
		double a,b,c;
		a=3.0/0;
		b=0/4.0;
		c=0/0.0;
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
				
	}

}
