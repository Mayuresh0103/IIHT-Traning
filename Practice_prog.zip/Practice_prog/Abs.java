package Practice_prog;

import java.util.Scanner;

public class Abs {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input array representing distances between stops
        System.out.print("Enter the distances between stops (comma-separated): ");
        String distancesInput = scanner.nextLine();
        String[] distancesStrArray = distancesInput.split(",");
        int[] distances = new int[distancesStrArray.length];

        for (int i = 0; i < distancesStrArray.length; i++) {
            distances[i] = Integer.parseInt(distancesStrArray[i].trim());
        }

        // Input the number of tires
        System.out.print("Enter the number of tires: ");
        int numTires = scanner.nextInt();

        int maxStops = findMaxStops(distances, numTires);
        System.out.println("Maximum number of stops with " + numTires + " tires: " + maxStops);

        scanner.close();
    }

    private static int findMaxStops(int[] distances, int numTires) {
        int stops = 0;
        int currentTires = numTires;

        for (int distance : distances) {
            if (currentTires >= distance) {
                // If there are enough tires, continue to the next stop
                currentTires -= distance;
                stops++;
            } else {
                // If not enough tires, refill and continue to the next stop
                currentTires = numTires - distance;
                stops++;
            }
        }

        return stops;
    }
}
