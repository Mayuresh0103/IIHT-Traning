package Streams_prog;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EndWithLetters {

	public static void main(String[] args) {
		
		List<String>listofStrings = Arrays.asList("cat","bat","rat","masch","simple");
		
		List<String>resultList = listofStrings.stream()
				.filter(s->s.endsWith("t"))
				.collect(Collectors.toList());
		
		System.out.println("Original list"+listofStrings);
		
		System.out.println("Result list"+resultList);
	}

}
