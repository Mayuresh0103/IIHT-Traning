package Streams_prog;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Demo_Stream_Starts {

	public static void main(String[] args) {
		String s= "the times of india";
		
		Map<Character,Long>CharCount = s.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
         System.out.println("Character counts:" + CharCount);
	
	}

}
