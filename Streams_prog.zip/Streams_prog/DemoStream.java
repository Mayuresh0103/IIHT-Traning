package Streams_prog;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Map;

public class DemoStream {
    public static void main(String[] args) {
    	List<String> words= Arrays.asList("java" , "sql" ,"java", "java", "spring", "sql", "good"); 

    	Map<String,Long> wordCountMap = words.stream().collect(Collectors.groupingBy(String::toLowerCase, Collectors.counting()));
    										
    	
    	System.out.println("Word count: " + wordCountMap);
    	    	
}






}
//Map map = (Map) Arrays.stream(str.split(" ")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting());




			