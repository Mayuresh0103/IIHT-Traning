package Streams_prog;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StartsWithNumber {

	public static void main(String[] args) {
	
		List<Integer>numbers = Arrays.asList(256,563,222,245,322,665,866,237);
		
		List<Integer> resultIntegers = numbers.stream()
											.map(Object::toString)
											.filter(s->s.startsWith("2"))
											.map(Integer::parseInt)
											.collect(Collectors.toList());
		
		System.out.println("Result is:"+resultIntegers);
		
	}

}
