package Streams_prog;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StartsWithLetter {

	public static void main(String[] args) {
		
		List<String>letterStrings = Arrays.asList("apple", "bannana","animal","and");

		List<String>resultList = letterStrings.stream().filter(s->s.startsWith("a")).collect(Collectors.toList());
		
		System.out.println("Original list"+ letterStrings);
		System.out.println("Result list"+resultList);
	}

}
