class Vehicle{

    String brand ="TATA";

    public void display()
    {
        System.out.println("Welcome to TATA");
    }
}


public class Car extends Vehicle{
    String Model ="NEXON";

    public static void main(String[] args){

        Car c = new Car();

        c.display();

    }
}
