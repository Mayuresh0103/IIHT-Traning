import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class DemoStream {

    public static void main(String[] args){

        List<Integer> nums = Arrays.asList(9,4,5,1,7,8,3);

        nums.stream()
                .filter(n->n%2==0)
                .sorted()
                .map(n->n*3)
                .forEach(n->System.out.println(n));

       // Stream<Integer> da =nums.stream();
        //long count = da.count();
        //System.out.println("Total ="+ count );
       // Stream<Integer> da =nums.stream();

    }
}
