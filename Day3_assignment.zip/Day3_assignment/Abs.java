abstract class Animal{
    public abstract void nameA();

    public void info(){
        System.out.println("I an animal");
    }
}

class Tiger extends Animal{
    public void sound(){

        System.out.println("Tiger roar");
    }

    @Override
    public void nameA() {
        System.out.println("I am tiger");
    }
}



public class Abs {
    public static void main(String[] args){

        Tiger t =new Tiger();
        t.info();
        t.sound();
        t.nameA();

    }

}
