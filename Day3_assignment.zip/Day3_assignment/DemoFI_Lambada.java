@FunctionalInterface
interface A{
    void show();
    String toString();

}
/*
class B implements A {
    @Override
    public void show(){
        System.out.println("hello");
    }
}
*/

public class DemoFI {

    public static void main(String[] args){

        A a=() ->System.out.println("hello inside main");
        a.show();
    }

}
