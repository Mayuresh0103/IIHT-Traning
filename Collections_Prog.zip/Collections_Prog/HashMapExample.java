package Collections_Prog;

import java.util.Map; 
import java.util.HashMap; 

public class HashMapExample {

	public static void main(String[] args) {


		
		// Java program to demonstrate iteration over 
		// Map.entrySet() entries using for-each loop 

		 Map<String,String> gfg = new HashMap<String,String>(); 
	      
	        // enter name/url pair 
	        gfg.put("One", "Apple"); 
	        gfg.put("Two", "Banana"); 
	        gfg.put("Three", "Mango"); 
	        gfg.put("Four", "Strawberry"); 
	          
	        // using for-each loop for iteration over Map.entrySet() 
	        for (Map.Entry<String,String> entry : gfg.entrySet())  
	            System.out.println("Key = " + entry.getKey() + 
	                             ", Value = " + entry.getValue()); 

		}

}
