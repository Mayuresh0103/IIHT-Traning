package Collections_Prog;

import java.util.Enumeration;
import java.util.Hashtable;

public class HashTableExample {
    public static void main(String[] args) {
        // Creating a HashTable
        Hashtable<Integer, String> hashTable = new Hashtable<>();

        // Adding elements to the HashTable
        hashTable.put(1, "One");
        hashTable.put(2, "Two");
        hashTable.put(3, "Three");
        hashTable.put(4, "Four");
        hashTable.put(5, "Five");

        // Displaying contents using Enumeration
        displayHashTableContents(hashTable);
    }

    private static void displayHashTableContents(Hashtable<Integer, String> hashTable) {
        // Getting Enumeration of keys
        Enumeration<Integer> keys = hashTable.keys();

        // Iterate through the keys and display corresponding values
        while (keys.hasMoreElements()) {
            Integer key = keys.nextElement();
            String value = hashTable.get(key);
            System.out.println("Key: " + key + ", Value: " + value);
        }
    }
}
